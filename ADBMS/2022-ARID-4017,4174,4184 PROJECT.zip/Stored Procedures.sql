--ADD PRODUCT
CREATE PROCEDURE AddProduct
    @ProductName NVARCHAR(100),
    @CategoryID INT,
    @SupplierID INT,
    @QuantityPerUnit NVARCHAR(50),
    @UnitPrice DECIMAL(18, 2),
    @UnitsInStock INT
AS
BEGIN
    INSERT INTO Products (ProductName, CategoryID, SupplierID, QuantityPerUnit, UnitPrice, UnitsInStock)
    VALUES (@ProductName, @CategoryID, @SupplierID, @QuantityPerUnit, @UnitPrice, @UnitsInStock);
END;

--UPDATE STOCK
CREATE PROCEDURE UpdateStock
    @ProductID INT,
    @Quantity INT
AS
BEGIN
    UPDATE Stock
    SET Quantity = Quantity + @Quantity
    WHERE ProductID = @ProductID;
END;

CREATE TYPE OrderDetailsType AS TABLE
(
    ProductID INT,
    Quantity INT,
    UnitPrice DECIMAL(18, 2)
);

--PLACE ORDER
CREATE PROCEDURE PlaceOrder
    @CustomerID INT,
    @ShipAddress NVARCHAR(255),
    @ShipCity NVARCHAR(50),
    @ShipPostalCode NVARCHAR(20),
    @ShipCountry NVARCHAR(50),
    @OrderDetails OrderDetailsType READONLY
AS
BEGIN
    DECLARE @OrderID INT;
    
    INSERT INTO Orders (CustomerID, ShipAddress, ShipCity, ShipPostalCode, ShipCountry)
    VALUES (@CustomerID, @ShipAddress, @ShipCity, @ShipPostalCode, @ShipCountry);
    
    SET @OrderID = SCOPE_IDENTITY();
    
    INSERT INTO OrderDetails (OrderID, ProductID, Quantity, UnitPrice)
    SELECT @OrderID, ProductID, Quantity, UnitPrice
    FROM @OrderDetails;
    
    DECLARE cur CURSOR FOR
    SELECT ProductID, Quantity
    FROM @OrderDetails;
    
    DECLARE @ProductID INT, @OrderQuantity INT;
    
    OPEN cur;
    
    FETCH NEXT FROM cur INTO @ProductID, @OrderQuantity;
    
    WHILE @@FETCH_STATUS = 0
    BEGIN
        EXEC UpdateStock @ProductID, @OrderQuantity;
        FETCH NEXT FROM cur INTO @ProductID, @OrderQuantity;
    END;
    
    CLOSE cur;
    DEALLOCATE cur;
END;

