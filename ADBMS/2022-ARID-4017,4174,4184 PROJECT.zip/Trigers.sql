CREATE TRIGGER trg_UpdateStk
ON OrderDetails
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    IF EXISTS (SELECT * FROM inserted)
    BEGIN
        DECLARE @ProductID INT, @Quantity INT;
        SELECT @ProductID = ProductID, @Quantity = Quantity FROM inserted;
        
        UPDATE Stock
        SET Quantity = Quantity - @Quantity
        WHERE ProductID = @ProductID;
    END
    
    IF EXISTS (SELECT * FROM deleted)
    BEGIN
        DECLARE @ProductID INT, @Quantity INT;
        SELECT @ProductID = ProductID, @Quantity = Quantity FROM deleted;
        
        UPDATE Stock
        SET Quantity = Quantity + @Quantity
        WHERE ProductID = @ProductID;
    END
END;
